from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import pymysql
import time
import sys

#잡코리아 크롤링

def job_create(jobtable):
    conn = pymysql.connect(host='localhost', user='root', password='qhfk9924', db='capstone',charset='utf8mb4')
    cur = conn.cursor()
    sql = f'''
    CREATE TABLE IF NOT EXISTS `{jobtable}` (
        `채용회사` VARCHAR(255) NOT NULL,
        `채용정보` VARCHAR(255) DEFAULT NULL,
        `채용링크` VARCHAR(255) DEFAULT NULL,
        PRIMARY KEY (`채용회사`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    '''
    try:
        cur.execute(sql)
        conn.commit()
        print('테이블생성 완료')
    except pymysql.MySQLError as e:
        print('테이블생성 실패')
        print(f"Error occurred: {e}")
    finally:
        conn.close()
        
def job_insert(jobtable,job_list):
    conn=pymysql.connect(host='localhost',user='root',password='qhfk9924',db='capstone',charset='utf8mb4')
    cur=conn.cursor()
    sql=f'replace into {jobtable} values (%s,%s,%s)'
    try:
        cur.executemany(sql,job_list)
        conn.commit()
        print('채용정보저장 성공')
    except pymysql.MySQLError as e:
        print('채용정보저장 실패')
        print(f"Error occurred: {e}")
    finally:
        conn.close()

# a=input('자격증 : ')

chrome_options = Options()
chrome_options.add_argument('--headless=new')
a=sys.argv[1]
jobtable='job_'+a

with webdriver.Chrome(service=Service(ChromeDriverManager().install()),options=chrome_options) as driver:
    driver.get('https://www.jobkorea.co.kr/')
    driver.implicitly_wait(2)
    
    search = driver.find_element(By.ID, 'stext')
    driver.execute_script("arguments[0].click();", search)
    search.send_keys(a)
    search.send_keys(Keys.RETURN)

    driver.implicitly_wait(2)
   
    
    job_list=[]
    for i in range(1,11,1):
        j=[]
        link_name=driver.find_element(By.XPATH,f'/html/body/main/div/article/article/section[1]/article[2]/article[{i}]/div[1]/a')
        link_title=driver.find_element(By.XPATH,f'/html/body/main/div/article/article/section[1]/article[2]/article[{i}]/div[2]/div/a')
        link_src=link_title.get_attribute('href') 
        for i in range(1):                   
            j.append(link_name.text)
            j.append(link_title.text)
            j.append(link_src)
        job_list.append(j)
    
        
  
job_create(jobtable)
job_insert(jobtable, job_list)    
    
    
    
    
    

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import pymysql
import time
import sys

#취득방법,진로및전망 저장

def insert_info(tablename,join1,join2,join3):
    conn = pymysql.connect(host='localhost', user='root', password='qhfk9924', db='capstone', charset='utf8mb4')
    cur = conn.cursor()
    sql = f'update certificate set 개요=%s,취득방법=%s,진로=%s where certifi_id="{tablename}"'
    try:
        cur.execute(sql,(join1,join2,join3))
        conn.commit()
        print('시험정보 저장 성공')
    except pymysql.MySQLError as e:
        print('시험정보 저장 실패')
        print(f"Error occurred: {e}")
    finally:
        conn.close()    

if __name__ == '__main__':
    
    tablename = sys.argv[1]
    chrome_options = Options()
    chrome_options.add_argument('--headless=new')
    
    with webdriver.Chrome(service=Service(ChromeDriverManager().install()),options=chrome_options) as driver:
        driver.get('https://www.q-net.or.kr/crf005.do?id=crf00501&gSite=Q&gId=')
        driver.implicitly_wait(3)
        search = driver.find_element(By.ID, 'jmNm')
        search.click()
        search.send_keys(tablename)
        search.send_keys(Keys.RETURN)
        driver.implicitly_wait(2)
        
        iframes = driver.find_elements(By.XPATH, '//*[@id="tab1"]/div/div/iframe')
        for iframe in iframes:
            title=iframe.get_attribute('title')
            if title == '취득방법 내용':
                driver.switch_to.frame(iframe)
                time.sleep(2)
                elements=driver.find_elements(By.TAG_NAME,'body')
                join2=''
                for element in elements:
                    text=element.text
                    join2+=text+'<br>'
                
      
        
        driver.switch_to.default_content()
        tap=driver.find_element(By.XPATH,'/html/body/div[7]/div[1]/div[2]/article/div[5]/div/div[3]/form/div[3]/ul/li[2]/a')
        tap.click()
        driver.implicitly_wait(2)
       
        iframes2=driver.find_elements(By.XPATH,'//*[@id="tab2"]/div/div/ul/li/iframe') 
        for iframe in iframes2:
            title=iframe.get_attribute('title')
            if title == '진로 및 전망 내용':
                driver.switch_to.frame(iframe)
                time.sleep(2)
                elements2=driver.find_elements(By.TAG_NAME,'body')
                join3=''
                for element in elements2:
                    text=element.text
                    join3+=text+'<br>'
                break    
            
        driver.switch_to.default_content()            
        driver.implicitly_wait(2)        
        
        iframes3=driver.find_elements(By.XPATH,'//*[@id="tab2"]/div/div/ul/li/iframe') 
        for iframe in iframes3:
            title=iframe.get_attribute('title')
            if title == '개요 내용':   
                driver.switch_to.frame(iframe)
                time.sleep(2)
                elements3=driver.find_element(By.TAG_NAME,'body')
                join1=elements3.text
                break 
                    
              
        insert_info(tablename,join1,join2,join3)


    
            
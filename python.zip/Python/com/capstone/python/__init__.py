from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import pymysql
import time
import subprocess

class DatabaseManager:
    def __init__(self):
        # MySQL 연결 초기화
        self.conn = pymysql.connect(host='localhost', user='root', password='qhfk9924', db='capstone', charset='utf8mb4')
    
    def create_table(self, tablename, field_list):
        cur = self.conn.cursor()
        sql = f'''
        CREATE TABLE IF NOT EXISTS `{tablename}` (
            `{field_list[0]}` VARCHAR(255) NOT NULL,
            `{field_list[1]}` VARCHAR(255) DEFAULT NULL,
            `{field_list[2]}` VARCHAR(255) DEFAULT NULL,
            `{field_list[3]}` VARCHAR(255) DEFAULT NULL,
            `{field_list[4]}` VARCHAR(255) DEFAULT NULL,
            `{field_list[5]}` VARCHAR(255) DEFAULT NULL,
            `{field_list[6]}` VARCHAR(255) DEFAULT NULL,
            PRIMARY KEY (`{field_list[0]}`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        '''
        try:
            cur.execute(sql)
            self.conn.commit()
            print('테이블 생성 완료')
        except pymysql.MySQLError as e:
            print('테이블 생성 실패')
            print(f"Error occurred: {e}")

    def insert_schedule(self, tablename, table_list):
        if table_list[0][0] == '시험정보가 없습니다.':
            print('시험일정이 없습니다.')
        else:
            cur = self.conn.cursor()
            sql = f'REPLACE INTO {tablename} VALUES (%s, %s, %s, %s, %s, %s, %s)'
            try:
                cur.executemany(sql, table_list)
                self.conn.commit()
                print('시험일정 저장 성공')
            except pymysql.MySQLError as e:
                print('시험일정 저장 실패')
                print(f"Error occurred: {e}")

    def insert_info(self, tablename, fee):
        cur = self.conn.cursor()
        sql = 'INSERT INTO certificate (certifi_id,수수료) VALUES (%s, %s)'
        try:
            cur.execute(sql, (tablename, fee))
            self.conn.commit()
            print('시험정보 저장 성공')
        except pymysql.MySQLError as e:
            print('시험정보 저장 실패')
            print(f"Error occurred: {e}")

    def close_connection(self):
        self.conn.close()


if __name__ == '__main__':
    try:
        while True:
            
            want = input('1. 자격증등록 2. 시험일정변경 : ')
            
            tablename = input('자격증 : ')
            
            chrome_options = Options()
            chrome_options.add_argument('--headless=new')
            
            # Selenium을 사용하여 새로운 검색 및 데이터 수집 수행
            with webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options) as driver:
                driver.get('https://www.q-net.or.kr/man001.do?gSite=Q')
                driver.implicitly_wait(3)
                search = driver.find_element(By.ID, 'searchQuery')
                search.click()
                search.send_keys(tablename)
                search.send_keys(Keys.RETURN)
                time.sleep(2)

                table_list = []
                elements2 = driver.find_elements(By.XPATH, '//*[@id="contents"]/article/div/div[3]/div[1]/div[2]/div[2]/ul/li[1]/div[2]/table/tbody/tr')
                for i in range(1, len(elements2) + 1):
                    t = []
                    elements = driver.find_elements(By.XPATH, f'//*[@id="contents"]/article/div/div[3]/div[1]/div[2]/div[2]/ul/li[1]/div[2]/table/tbody/tr[{i}]/td')
                    for element in elements:
                        text = element.text
                        t.append(text.replace('\n', ' '))
                    table_list.append(t)

                field_list = []
                thead = driver.find_elements(By.XPATH, '//*[@id="contents"]/article/div/div[3]/div[1]/div[2]/div[2]/ul/li[1]/div[2]/table/thead/tr/th')
                for i in range(1, len(thead) + 1):
                    text = driver.find_element(By.XPATH, f'//*[@id="contents"]/article/div/div[3]/div[1]/div[2]/div[2]/ul/li[1]/div[2]/table/thead/tr/th[{i}]').text
                    field_list.append(text.replace('\n', ''))

                
                fee = driver.find_element(By.XPATH, '//*[@id="contents"]/article/div/div[3]/div[1]/div[2]/div[2]/ul/li/div[3]/table/tbody/tr/td').text

            
            #데이터베이스에 작업 수행
            crawling = DatabaseManager()
            if want == '2':
                crawling.insert_schedule(tablename, table_list)
            elif want == '1':
                crawling.create_table(tablename, field_list)
                crawling.insert_schedule(tablename, table_list)
                crawling.insert_info(tablename, fee)
            else :
                print('다시선택하세요')
            
            
            result = subprocess.run(['python3', '/Users/bora/capstone/Python/com/capstone/python/info.py',tablename],stdout=subprocess.PIPE, stderr=subprocess.PIPE,text=True)
            
            print("stdout:", result.stdout)  
              
            crawling.close_connection()

    except KeyboardInterrupt:
        print('\n프로그램을 종료합니다.')
        
        
package com.servlet.step2.model;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.servlet.step2.common.JdbcConnectUtil;



public class MemberDao {
	private static MemberDao mDao;
	private  Connection con;
	private PreparedStatement pstmt;
	private ResultSet rs;
	private int result;
	
    public boolean loginCheck(String id, String password) {
    	
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        boolean loginCon = false;
        try {
        	con = JdbcConnectUtil.getConnection();
            String strQuery = "select id, password from user where id = ? and password = ?";

            pstmt = con.prepareStatement(strQuery);
            pstmt.setString(1, id);
            pstmt.setString(2, password);
            rs = pstmt.executeQuery();
            loginCon = rs.next();
        } catch (Exception ex) {
            System.out.println("Exception" + ex);
        } finally {
        	JdbcConnectUtil.close(con, pstmt, null);
        }
        return loginCon;
    }	
	
    public boolean memberInsert(MemberDto mDTO) {
        Connection con = null;
        PreparedStatement pstmt = null;
        boolean flag = false;
        try {
        	con =  JdbcConnectUtil.getConnection();
            String strQuery = "insert into user values(?,?,?,?)";
            pstmt = con.prepareStatement(strQuery);
            pstmt.setString(1, mDTO.getId());
            pstmt.setString(2, mDTO.getPassword());
            pstmt.setString(3, mDTO.getName());
            pstmt.setString(4, mDTO.getPhone_num());

            int count = pstmt.executeUpdate();

            if (count == 1) {
                flag = true;
            }

        } catch (Exception ex) {
            System.out.println("Exception" + ex);
        } finally {
        	JdbcConnectUtil.close(con, pstmt, null);
        }
        return flag;
    }	
	
    public boolean memberUpdate(MemberDto mDTO) {
        Connection con = null;
        PreparedStatement pstmt = null;
        boolean flag = false;
        try {
        	con =  JdbcConnectUtil.getConnection();
            String strQuery = "update user set name=?, password=?, phone_num=? where id=?";
  

            pstmt = con.prepareStatement(strQuery);
            pstmt.setString(1, mDTO.getName());
            pstmt.setString(2, mDTO.getPassword());
            pstmt.setString(3, mDTO.getPhone_num());
            pstmt.setString(4, mDTO.getId());
           
            int count = pstmt.executeUpdate();

            if (count == 1) {
                flag = true;
            }
        } catch (Exception ex) {
            System.out.println("Exception" + ex);
        } finally {
        	JdbcConnectUtil.close(con, pstmt, null);
        }
        return flag;
    }

    public MemberDto getMember(String id) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        MemberDto mDTO = null;

        try {
        	con =  JdbcConnectUtil.getConnection();
            String strQuery = "select * from user where id=?";
            pstmt = con.prepareStatement(strQuery);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();

            if (rs.next()) {
            	mDTO = new MemberDto();
            	mDTO.setId(rs.getString("id"));
            	mDTO.setPassword(rs.getString("password"));
            	mDTO.setName(rs.getString("name"));
            	mDTO.setPhone_num(rs.getString("phone_num"));
            }
        } catch (Exception ex) {
            System.out.println("Exception" + ex);
        } finally {
        	JdbcConnectUtil.close(con, pstmt, null);
        }
        return mDTO;
    }

}

package com.servlet.step2.common;

public class ViewResolver {
	public String prefix;  // "./"접두사
	public String suffix;  // ".jsp"접미사

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getView(String viewName) {   //"Index"
		return prefix + viewName + suffix;   // "./Index.jsp" 
	}
}

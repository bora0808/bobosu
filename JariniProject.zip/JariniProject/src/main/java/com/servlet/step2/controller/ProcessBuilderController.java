package com.servlet.step2.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.servlet.step2.common.Controller;
import com.servlet.step2.model.CertifiDao;
import com.servlet.step2.model.CertifiDto;

public class ProcessBuilderController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response)  {
			String certifi_id=request.getParameter("certifi_id");
			String path="/Users/bora/capstone/Python/com/capstone/python/job.py";
			
			ProcessBuilder pb=new ProcessBuilder("python3",path,certifi_id);
			Process p = null;
			try {
				p = pb.start();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			InputStream inputStream =p.getInputStream();
			BufferedReader reader=new BufferedReader(new InputStreamReader(inputStream));
			String line;
			try {
				while ((line = reader.readLine()) != null){
				    System.out.println(">>> " + line);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CertifiDao cDao =new CertifiDao();
			
			List<Map<String, String>> joblist=cDao.getJsonResponse(certifi_id);
			
			HttpSession session = request.getSession();
			session.setAttribute("joblist",joblist);
		
			
			
		return "info_detail";
	}

}

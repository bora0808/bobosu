package com.servlet.step2.model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import com.servlet.step2.common.JdbcConnectUtil;


public class BoardDao {
	private Connection con;
	private ResultSet rs;
	private PreparedStatement pstmt;
	
	public String getDate() {
		 Connection con = null;
		 PreparedStatement pstmt = null;
	     ResultSet rs = null;
		String strQuery = "SELECT NOW()";
		try {
	    	con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(strQuery);
	        rs = pstmt.executeQuery();
			
			if(rs.next()) {
				return rs.getString(1);
			}
						
		} catch(Exception e) {
			e.printStackTrace();
		}
		return ""; // 데이터베이스 오류
	}
	
	public int getNext() {
		 Connection con = null;
		 PreparedStatement pstmt = null;
	     ResultSet rs = null;
		String strQuery = "SELECT bbsId FROM BBS ORDER BY bbsId DESC";
		try {
	    	con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(strQuery);
	        rs = pstmt.executeQuery();
			
			if(rs.next()) {
				return rs.getInt(1)+1;
			}
			return 1;
						
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1; // 데이터베이스 오류
	}
	

	public int write(String bbsTitle, String userId, String bbsContent) {
		 Connection con = null;
		 PreparedStatement pstmt = null;
	    
		String strQuery = "INSERT INTO BBS VALUES (?, ?, ?, ?, ?,?)";
		try {
			con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(strQuery);
			
	        int nextId = getNext();
	        String currentDate = getDate();
	  
			pstmt.setInt(1, nextId);
			pstmt.setString(2,bbsTitle);
			pstmt.setString(3,userId);
			pstmt.setString(4, currentDate);
			pstmt.setString(5, bbsContent);
			pstmt.setInt(6,1);
			
			int result = pstmt.executeUpdate();
	
	        return result;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1; // 데이터베이스 오류
	}
	
	public ArrayList<BoardDto> getList(int pageNumber){
		 Connection con = null;
		 PreparedStatement pstmt = null;
	     ResultSet rs = null;
	     
		String strQuery = "SELECT * FROM BBS WHERE bbsId < ? AND bbsAvailable = 1 ORDER BY bbsId DESC LIMIT 10";
		
		ArrayList<BoardDto> list = new ArrayList<BoardDto>();
		
		try {
			con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(strQuery);
			pstmt.setInt(1,  getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				BoardDto bbs = new BoardDto();
				bbs.setBbsId(rs.getInt(1));
				bbs.setBbsTitle(rs.getString(2));
				bbs.setUserId(rs.getString(3));
				bbs.setBbsDate(rs.getString(4));
				bbs.setBbsContent(rs.getString(5));
				bbs.setBbsAvailable(rs.getInt(6));
				list.add(bbs);
			}
						
		} catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public boolean nextPage(int pageNumber){
		 Connection con = null;
		 PreparedStatement pstmt = null;
	     ResultSet rs = null;
		String strQuery = "SELECT * FROM BBS WHERE bbsId < ? AND bbsAvailable = 1";
		
		try {
			con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(strQuery);
			pstmt.setInt(1,  getNext() - (pageNumber -1) * 10);
			rs= pstmt.executeQuery();
			
			if(rs.next()) {
				return true;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return false; // 데이터베이스 오류
	}
	
	public BoardDto getBbs(int bbsId) {
		 Connection con = null;
		 PreparedStatement pstmt = null;
	     ResultSet rs = null;
		String strQuery = "SELECT * FROM BBS WHERE bbsId = ?";
		
		try {
			con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(strQuery);
			pstmt.setInt(1,  bbsId);
			rs= pstmt.executeQuery();
			if(rs.next())
			{
				BoardDto bbs = new BoardDto();
				bbs.setBbsId(rs.getInt(1));
				bbs.setBbsTitle(rs.getString(2));
				bbs.setUserId(rs.getString(3));
				bbs.setBbsDate(rs.getString(4));
				bbs.setBbsContent(rs.getString(5));
				bbs.setBbsAvailable(rs.getInt(6));
				return bbs;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null; // 데이터베이스 오류
	}
	
	public int update(int bbsId, String bbsTitle, String bbsContent) {
		 Connection con = null;
		 PreparedStatement pstmt = null;
	   
		String strQuery = "UPDATE BBS SET bbsTitle = ?, bbsContent = ? WHERE bbsId = ?";
		try {
			con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(strQuery);
			
			pstmt.setString(1,  bbsTitle);
			pstmt.setString(2,  bbsContent);
			pstmt.setInt(3,  bbsId);
			return pstmt.executeUpdate();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1; // 데이터베이스 오류
	}
	
	public int delete(int bbsId) {
		 Connection con = null;
		 PreparedStatement pstmt = null;
		String strQuery = "UPDATE BBS SET bbsAvailable = 0 WHERE bbsId = ?";
		try {
			con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(strQuery);
			pstmt.setInt(1,  bbsId);
			return pstmt.executeUpdate();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1; // 데이터베이스 오류
	}
	
	
	
	
	
	
	
	
	
}

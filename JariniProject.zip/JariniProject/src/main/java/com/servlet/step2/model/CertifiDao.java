package com.servlet.step2.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.servlet.step2.common.JdbcConnectUtil;

public class CertifiDao {
	private static MemberDao mDao;
	private  Connection con;
	private PreparedStatement pstmt;
	private ResultSet rs;
	private int result;
	
	public CertifiDto getCertificate(String certifi_id) {
		    Connection con = null;
		    PreparedStatement pstmt = null;
		    ResultSet rs = null;
		    CertifiDto cerBean = null;
		
		    try {
		    	con = JdbcConnectUtil.getConnection();
		        String strQuery = "select * from certificate where certifi_id=?";
		        pstmt = con.prepareStatement(strQuery);
		        pstmt.setString(1, certifi_id);
		        rs = pstmt.executeQuery();
		    
		        if (rs.next()) {
		        	cerBean = new CertifiDto();
		        	cerBean.setCertifi_id(rs.getString("certifi_id"));
		        	cerBean.setInform(rs.getString("개요"));
		        	cerBean.setFee(rs.getString("수수료"));
		        	cerBean.setStep(rs.getString("취득방법"));
		    		cerBean.setWay(rs.getString("진로"));}
	
		        } catch (Exception ex) {
		        System.out.println("Exception" + ex);
			    } finally {
			    	JdbcConnectUtil.close(con, pstmt, rs);
			    }
		    
	 
		    return cerBean;
	 }
	
	 public Vector getCertifiList() {
	     Connection con = null;
	     Statement stmt = null;
	     ResultSet rs = null;
	     Vector<CertifiDto> vecList = new Vector();

	     try {
	    	 con = JdbcConnectUtil.getConnection();
	         String strQuery = "select * from certificate";
	         stmt = con.createStatement();
	         rs = stmt.executeQuery(strQuery);

	         while (rs.next()) {
	             CertifiDto cerBean = new CertifiDto();
	             cerBean.setCertifi_id(rs.getString("certifi_id"));
	             vecList.add(cerBean);
	         }
	     } catch (Exception ex) {
	         System.out.println("Exception" + ex);
	     } finally {
	    	 JdbcConnectUtil.close(con, pstmt, rs);

	     }
	     return vecList;
	 }
	 
	 public Vector getScheduleList(String certifi_id) {
	     Connection con = null;
	     Statement stmt = null;
	     ResultSet rs = null;
	     Vector vecList = new Vector();
	     
	 
	     try {
	    	 con = JdbcConnectUtil.getConnection();
	         String strQuery = "select * from "+certifi_id;
	         stmt = con.createStatement();
	         rs = stmt.executeQuery(strQuery);

	        
		         while (rs.next()) {
		             CertifiDto cerBean = new CertifiDto();
		             cerBean.setField1(rs.getString(1));
		             cerBean.setField2(rs.getString(2));
		             cerBean.setField3(rs.getString(3));
		             cerBean.setField4(rs.getString(4));
		             cerBean.setField5(rs.getString(5));
		             cerBean.setField6(rs.getString(6));
		             cerBean.setField7(rs.getString(7));
		             
		             vecList.add(cerBean);
		         }
	
	     } catch (Exception ex) {
	         System.out.println("Exception" + ex);
	     } finally {
	    	 JdbcConnectUtil.close(con, pstmt, rs);

	     }
	     return vecList;
	 }
	
		public CertifiDto getColumnName(String certifi_id) {
		    Connection con = null;
		    Statement stmt = null;
		    ResultSet rs = null;
		    CertifiDto cerBean = null;
		    ResultSetMetaData rsmd;
		
		    try {
		    	con = JdbcConnectUtil.getConnection();
		        String strQuery = "select * from "+certifi_id;
		        stmt = con.createStatement();
		        rs = stmt.executeQuery(strQuery);
		        rsmd=rs.getMetaData();
		    
		      
		        	cerBean = new CertifiDto();
		        	cerBean.setColname1(rsmd.getColumnName(1));
		        	cerBean.setColname2(rsmd.getColumnName(2));
		        	cerBean.setColname3(rsmd.getColumnName(3));
		        	cerBean.setColname4(rsmd.getColumnName(4));
		        	cerBean.setColname5(rsmd.getColumnName(5));
		        	cerBean.setColname6(rsmd.getColumnName(6));
		        	cerBean.setColname7(rsmd.getColumnName(7));
		       
		        
	
		        } catch (Exception ex) {
		        System.out.println("Exception" + ex);
			    } finally {
			    	JdbcConnectUtil.close(con, pstmt, rs);
			    }
		    
	 
		    return cerBean;
	 }
	
		public List<Map<String, String>> getJsonResponse(String certifi_id) {
		     Connection con = null;
		     Statement stmt = null;
		     ResultSet rs = null;
		     List<Map<String, String>> jobList = new ArrayList<>();
		    
		     
		 
		     try {
		    	 con = JdbcConnectUtil.getConnection();
		         String strQuery = "select * from "+"job_"+certifi_id;
		         stmt = con.createStatement();
		         rs = stmt.executeQuery(strQuery);

		        
		         

		         while (rs.next()) {
		             Map<String, String> job = new HashMap<>();
		             job.put("company", rs.getString("채용회사"));
		             job.put("title", rs.getString("채용정보"));
		             job.put("link", rs.getString("채용링크"));

		             jobList.add(job);
		         }
			         
		
		     } catch (Exception ex) {
		         System.out.println("Exception" + ex);
		     } finally {
		    	 JdbcConnectUtil.close(con, pstmt, rs);

		     }
		     
		     
		     return jobList;
		}
		
		public ArrayList<CertifiDto> getKeyword(String keyword) {
		    Connection con = null;
		    PreparedStatement pstmt = null;
		    ResultSet rs = null;
		    CertifiDto cerBean = null;
		    ArrayList<CertifiDto> list = new ArrayList<CertifiDto>();
		    
		    try {
		    	con = JdbcConnectUtil.getConnection();
		        String strQuery = "select certifi_id,개요 from certificate where certifi_id like '%"+keyword+"%' limit 10";
		        pstmt = con.prepareStatement(strQuery);
		        
		        rs = pstmt.executeQuery();
		    
		        while (rs.next()) {
		        	cerBean = new CertifiDto();
		        	cerBean.setCertifi_id(rs.getString("certifi_id"));
		        	cerBean.setInform(rs.getString("개요"));
		        	list.add(cerBean);}
		        
		 
	
		        } catch (Exception ex) {
		        System.out.println("Exception" + ex);
			    } finally {
			    	JdbcConnectUtil.close(con, pstmt, rs);
			    }
		    
	 
		    return list;
		}
}

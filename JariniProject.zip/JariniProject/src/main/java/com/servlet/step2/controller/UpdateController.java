package com.servlet.step2.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.servlet.step2.common.Controller;
import com.servlet.step2.model.MemberDao;
import com.servlet.step2.model.MemberDto;

public class UpdateController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		String pw = request.getParameter("password");
		String name = request.getParameter("name");
		String phone_num = request.getParameter("phone_num");

		MemberDto mDto = new MemberDto();
		mDto.setId(id);
		mDto.setPassword(pw);
		mDto.setName(name);
		mDto.setPhone_num(phone_num);		
		
		MemberDao mDao = new MemberDao();	
		boolean updateCheck = mDao.memberUpdate(mDto);

	    if(updateCheck){
	    	System.out.println("수정 완료");
	    	request.setAttribute("updateResult", updateCheck);
			HttpSession session = request.getSession();
			session.setAttribute("idKey", id);
			session.setAttribute("member", mDto);
			return "main";

		}else{
	    	request.setAttribute("updateResult", 0);
	    	return "MemberUpdate";
		}

	}

}

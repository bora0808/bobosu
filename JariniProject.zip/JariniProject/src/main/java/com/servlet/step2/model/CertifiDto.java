package com.servlet.step2.model;

public class CertifiDto {
	private String certifi_id;
	private String inform;
	private String fee;
	private String step;
	private String way;
	private String field1;
	private String field2;
	private String field3;
	private String field4;
	private String field5;
	private String field6;
	private String field7;
	private String colname1;
	private String colname2;
	private String colname3;
	private String colname4;
	private String colname5;
	private String colname6;
	private String colname7;
	private String jobenter;
	private String jobtitle;
	private String joblink;
	private String keyword;
	
	

	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getJobenter() {
		return jobenter;
	}
	public void setJobenter(String jobenter) {
		this.jobenter = jobenter;
	}
	public String getJobtitle() {
		return jobtitle;
	}
	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}
	public String getJoblink() {
		return joblink;
	}
	public void setJoblink(String joblink) {
		this.joblink = joblink;
	}
	public String getStep() {
		return step;
	}
	public void setStep(String step) {
		this.step = step;
	}
	public String getWay() {
		return way;
	}
	public void setWay(String way) {
		this.way = way;
	}
	public String getColname1() {
		return colname1;
	}
	public void setColname1(String colname1) {
		this.colname1 = colname1;
	}
	public String getColname2() {
		return colname2;
	}
	public void setColname2(String colname2) {
		this.colname2 = colname2;
	}
	public String getColname3() {
		return colname3;
	}
	public void setColname3(String colname3) {
		this.colname3 = colname3;
	}
	public String getColname4() {
		return colname4;
	}
	public void setColname4(String colname4) {
		this.colname4 = colname4;
	}
	public String getColname5() {
		return colname5;
	}
	public void setColname5(String colname5) {
		this.colname5 = colname5;
	}
	public String getColname6() {
		return colname6;
	}
	public void setColname6(String colname6) {
		this.colname6 = colname6;
	}
	public String getColname7() {
		return colname7;
	}
	public void setColname7(String colname7) {
		this.colname7 = colname7;
	}
	public String getCertifi_id() {
		return certifi_id;
	}
	public void setCertifi_id(String certifi_id) {
		this.certifi_id = certifi_id;
	}
	public String getInform() {
		return inform;
	}
	public void setInform(String inform) {
		this.inform = inform;
	}
	public String getFee() {
		return fee;
	}
	public void setFee(String fee) {
		this.fee = fee;
	}
	public String getField1() {
		return field1;
	}
	public void setField1(String field1) {
		this.field1 = field1;
	}
	public String getField2() {
		return field2;
	}
	public void setField2(String field2) {
		this.field2 = field2;
	}
	public String getField3() {
		return field3;
	}
	public void setField3(String field3) {
		this.field3 = field3;
	}
	public String getField4() {
		return field4;
	}
	public void setField4(String field4) {
		this.field4 = field4;
	}
	public String getField5() {
		return field5;
	}
	public void setField5(String field5) {
		this.field5 = field5;
	}
	public String getField6() {
		return field6;
	}
	public void setField6(String field6) {
		this.field6 = field6;
	}
	public String getField7() {
		return field7;
	}
	public void setField7(String field7) {
		this.field7 = field7;
	}

}

package com.servlet.step2.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.servlet.step2.common.Controller;
import com.servlet.step2.model.CertifiDao;
import com.servlet.step2.model.CertifiDto;

public class SearchController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) {
		
	    String keyword=request.getParameter("keyword");
			
		
		CertifiDao cDao=new CertifiDao();
		ArrayList<CertifiDto> list= cDao.getKeyword(keyword);
		
		HttpSession session = request.getSession();
		session.setAttribute("searchList",list);
		
		return "info";
	}

}

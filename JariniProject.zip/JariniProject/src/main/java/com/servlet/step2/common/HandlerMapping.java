﻿package com.servlet.step2.common;

import java.util.HashMap;
import java.util.Map;

import com.servlet.step2.controller.CertificateController;
import com.servlet.step2.controller.JoinController;
import com.servlet.step2.controller.LoginController;
import com.servlet.step2.controller.LogoutController;
import com.servlet.step2.controller.MemberController;
import com.servlet.step2.controller.ProcessBuilderController;
import com.servlet.step2.controller.SearchController;
import com.servlet.step2.controller.UpdateController;



public class HandlerMapping {
	private Map<String, Controller> mappings;

	public HandlerMapping() {
		mappings = new HashMap<String, Controller>(); 
		mappings.put("/login.do", new LoginController()); 
		mappings.put("/logout.do", new LogoutController());	
		mappings.put("/join.do", new JoinController());	
		mappings.put("/update.do", new UpdateController());	
		mappings.put("/info.do", new CertificateController());
		mappings.put("/job.do", new ProcessBuilderController());
		mappings.put("/search.do", new SearchController());
		mappings.put("/mem.do", new MemberController());
	}
	

	public Controller getController(String path) {  //"/login.do"
		return mappings.get(path);
	}
}


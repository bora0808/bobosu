package com.servlet.step2.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.servlet.step2.common.Controller;
import com.servlet.step2.model.MemberDao;
import com.servlet.step2.model.MemberDto;



//인터페이스 컨트롤러클래스를 상속받아 추상메서드 오버라이딩
public class JoinController implements Controller {
	@Override	
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) {
		
		String id = request.getParameter("id");
		String pw = request.getParameter("password");
		String name = request.getParameter("name");
		String phone_num = request.getParameter("phone_num");

		MemberDto mDto = new MemberDto();
		mDto.setId(id);
		mDto.setPassword(pw);
		mDto.setName(name);
		mDto.setPhone_num(phone_num);		
		
		MemberDao mDao = new MemberDao();	
		boolean insertCheck = mDao.memberInsert(mDto);
		

	    if(insertCheck){
	    	request.setAttribute("joinResult", insertCheck);
			HttpSession session = request.getSession();
			session.setAttribute("idKey", id);
			session.setAttribute("member", mDto);
			return "main";

		}else{
	    	request.setAttribute("joinResult", 0);
	    	return "Register";
		}		
		
		
	}
	
		
	
}

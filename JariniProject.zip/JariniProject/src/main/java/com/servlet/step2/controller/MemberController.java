package com.servlet.step2.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.servlet.step2.common.Controller;
import com.servlet.step2.model.MemberDao;
import com.servlet.step2.model.MemberDto;
public class MemberController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		String pw = request.getParameter("password");
		String name = request.getParameter("name");
		String phone_num = request.getParameter("phone_num");

		MemberDto mDto = new MemberDto();
		mDto.setId(id);
		mDto.setPassword(pw);
		mDto.setName(name);
		mDto.setPhone_num(phone_num);		
		
		MemberDao mDao = new MemberDao();	
		boolean memberupdate = mDao.memberUpdate(mDto);
		
		HttpSession session = request.getSession();
		session.setAttribute("member",mDto);
		return "mypage";
	}

}

﻿package com.servlet.step2.controller;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.servlet.step2.common.Controller;
import com.servlet.step2.model.MemberDao;
import com.servlet.step2.model.MemberDto;


public class LoginController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) {
		
		String id = request.getParameter("id");
		String pw = request.getParameter("password");

		MemberDto vo = new MemberDto();
		vo.setId(id);
		vo.setPassword(pw);

		MemberDao userDAO = new MemberDao();
		boolean loginCheck = userDAO.loginCheck(id, pw);
		MemberDto mDTO=userDAO.getMember(id);

		if (loginCheck) {
	    	request.setAttribute("loginResult", loginCheck);
			HttpSession session = request.getSession();
			session.setAttribute("idKey", id);
			session.setAttribute("member", mDTO);
			return "main";
		} else {
			return "loginError";
		}
	}

}
